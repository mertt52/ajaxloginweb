<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <link rel="stylesheet" type="text/css" href="main.css"><style>img[alt="www.000webhost.com"]{display:none;}</style>
  <title>İtiraz Formunuz Başarıyla Gönderildi.</title>
  <meta name="viewport" content="width=device-width,inital-scale=1">
  <noscript>Please Active Javascirpt on your scanner</noscript>
  <link rel="stylesheet" href="releases/latest/css/free.min.css" media="all">
</head>

<body style="background:#fafafa;">



</div>
</div>

      <div style="font-weight:400; padding:0px; margin:0px; border:0px solid #ffffff; width:100%; background:white;">
        <br>
<center>

<img src="quaconfirm.gif"  width="250">
</center>
<center>
<h1 style="font-family:sans-serif;
font-weight:400;
letter-spacing:;
color:#3d3d3d;
font-size: 20px;"> <b>İtirazınız incelenecek ve en kısa sürede sizinle iletişime geçilecektir. (Dönüş süresi 1 veya 2 gün sürebilir.)</b></h1> 
<p style="max-width:88%; font-size:15px; color: #999; line-height:20px; font-weight:400;">
<br>İtirazınız için teşekkürler, hesabınız inceleniyor.
<br>
Bu süre içerisinde hesabınızdaki bilgilerinizi değiştirmeyiniz, bilgilerinizi değiştirmeniz halinde itirazınız kabul edilmeyecektir.
Şimdi sizi telif hakkı kurallarına yönlendireceğiz.
<br>
Instagram ekibi olarak topluluk kurallarına büyük önem veriyoruz.
<br><br><br>
<br><br>
  </div></center>
   <br><br><br><center>
  <div class="bottom">
    
    <img src="img/from.png"  width="115">
  </div>
</center>
  <script type='text/javascript'></script><style > 
    img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]{
     display:none!important;
    }
</style>
</body>
</html>
